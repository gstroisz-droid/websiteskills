# web-agent-skills

Skills for building production websites on two tracks from one design system:

- **WordPress + Astra** — child theme, Elementor or Spectra, importable delivery package
- **Cloudflare Workers** — static site or app, static assets plus dynamic handlers

Plain `SKILL.md` folders with no vendor-specific frontmatter, so they work in Claude Code, Codex,
and any other agent that reads the Agent Skills format.

---

## How it is structured, and why

Skill metadata sits in the agent's context permanently, whether or not the skill runs. Sixty skills
means sixty descriptions competing for attention, and the practical result is not a smarter agent
but a worse one — when ten descriptions mention "layout", the agent picks badly or picks nothing.

So the sixty capabilities are arranged in three levels:

```
level 0   build-orchestrator      always in context — one description, ~50 words
level 1   6 domain skills         description in context; body loaded when matched
level 2   ~55 modules             loaded only via a domain's routing table
```

Seven descriptions compete instead of sixty. Nothing is lost — a module is a file the domain skill
knows how to find, it simply stops shouting for attention until it is needed.

```
plugins/web-core/skills/
├── build-orchestrator/     level 0 — routing, project state, track decision
│   └── registry/catalog.json   full module index, read only when routing fails
├── project-discovery/      brief, information architecture
│   └── modules/
└── design-system/          tokens, art direction, layout, components
    ├── modules/
    ├── scripts/build-tokens.mjs
    ├── assets/tokens.example.json
    └── references/
```

---

## Install

### Claude Code

```
/plugin marketplace add <your-org>/web-agent-skills
/plugin install web-core@web-agent-skills
```

For local development, point the marketplace at the folder instead:

```
/plugin marketplace add /path/to/web-agent-skills
```

Install `web-core` on every project. Add the track package only when the project needs it —
a WordPress project should not carry Cloudflare skills, and the reverse. That is a second layer of
context savings on top of the module structure.

### Codex and other agents without skill discovery

Clone the repository into the project and point the agent at `AGENTS.md`, which indexes every
skill and states when to read which. Codex reads `AGENTS.md` automatically when it sits at the
repository root; for a nested clone, add one line to the project's own `AGENTS.md`:

```markdown
Website work: read web-agent-skills/AGENTS.md and follow its routing table.
```

### Manual copy

```
./install.sh ~/my-project           # core only
./install.sh ~/my-project wordpress # core + WordPress track
```

Copies the selected packages into `<project>/.claude/skills/`. Pass `--codex` to target
`~/.codex/skills` instead.

---

## Using it

Start every website task with the orchestrator. In practice this means saying what you want built —
`build-orchestrator` triggers on it, decides the track, and calls the domains in order. It writes
project state to `.site/` in the target project, which is what makes an interrupted build
resumable:

```
.site/
├── brief.md          what the site is for
├── ia.md             sitemap, URLs, templates
├── content-model.json
├── tokens.json       every visual decision, once
├── track.md          WordPress or Workers, and why
├── phase.md          where the build currently stands
└── decisions.md      append-only log
```

The single most useful piece is `tokens.json`. One file compiles to WordPress `theme.json`, an
Elementor kit fragment, CSS custom properties and a Tailwind theme:

```
node plugins/web-core/skills/design-system/scripts/build-tokens.mjs .site/tokens.json --out build/tokens
```

That is what keeps a site looking identical whether it ships on WordPress or on Workers.

---

## Batches

| Batch | Contents | Status |
|---|---|---|
| 1 | build-orchestrator, project-discovery, design-system/tokens | done |
| 2 | design-system: art-direction, typography, color, layout, components, motion, design-review | pending |
| 3 | wordpress-build (15 modules) | pending |
| 4 | cloudflare-build (9 modules) | pending |
| 5 | graphics-media (7 modules) | pending |
| 6 | content-copy (5) and quality-launch (12) | pending |

`registry/catalog.json` lists every planned module, so the orchestrator can answer "is there
anything for X" without loading any of them.

---

## Conventions

- Project state lives in `.site/` at the target project root, never in this repository
- Generated files are never hand-edited; regenerate from source
- Scripts are dependency-free Node 18+
- Packages are self-contained — a plugin never references files outside its own directory, because
  the plugin loader copies directories and those references would break
