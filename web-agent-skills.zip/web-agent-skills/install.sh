#!/usr/bin/env bash
# install.sh — copy skill packages into a project (or into Codex's skills directory)
#
#   ./install.sh ~/my-project                    core only
#   ./install.sh ~/my-project wordpress          core + WordPress track
#   ./install.sh ~/my-project wordpress cloudflare
#   ./install.sh --codex wordpress               into ~/.codex/skills
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"

if [ "${1:-}" = "--codex" ]; then
  TARGET="${CODEX_HOME:-$HOME/.codex}/skills"
  shift
else
  PROJECT="${1:-}"
  [ -z "$PROJECT" ] && { echo "usage: ./install.sh <project-dir> [wordpress] [cloudflare]"; exit 1; }
  TARGET="$PROJECT/.claude/skills"
  shift
fi

mkdir -p "$TARGET"

copy_package() {
  local pkg="$1"
  local dir="$SRC/plugins/$pkg/skills"
  if [ ! -d "$dir" ]; then
    echo "  skip $pkg (not built yet)"
    return
  fi
  for skill in "$dir"/*/; do
    name="$(basename "$skill")"
    rm -rf "${TARGET:?}/$name"
    cp -r "$skill" "$TARGET/$name"
    echo "  + $name"
  done
}

echo "installing into $TARGET"
copy_package "web-core"
for track in "$@"; do
  case "$track" in
    wordpress)  copy_package "web-wordpress" ;;
    cloudflare) copy_package "web-cloudflare" ;;
    *) echo "  unknown track: $track" ;;
  esac
done

echo
echo "done. Start a build by describing the site you want — build-orchestrator takes it from there."
