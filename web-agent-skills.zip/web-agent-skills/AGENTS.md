# Agent instructions

Skills for building websites. Each folder under `plugins/*/skills/` holds a `SKILL.md`, plus
optional `modules/`, `scripts/`, `references/` and `assets/`.

## Reading order

1. Any request to build, rebuild, redesign or migrate a website or web app: read
   `plugins/web-core/skills/build-orchestrator/SKILL.md` first. It routes everything else.
2. Read one domain `SKILL.md` at a time, based on the orchestrator's routing table.
3. Read a file under `modules/` only when the domain's own routing table sends you there.
4. Read `references/` only when a skill points at it.

Never read every skill to survey what is available. If routing fails, open
`plugins/web-core/skills/build-orchestrator/registry/catalog.json`, which indexes every module.

## Routing table

| The task is about | Read |
|---|---|
| Building or redesigning a site; choosing a platform; resuming a build | `build-orchestrator` |
| Goals, audience, scope, sitemap, URLs, navigation, content types | `project-discovery` |
| Colors, fonts, spacing, layout, components, design tokens | `design-system` |
| Astra, Elementor, WordPress themes, CPT, WooCommerce, WP packaging | `wordpress-build` (batch 3) |
| Astro, static builds, Workers, D1/KV/R2, edge | `cloudflare-build` (batch 4) |
| Logo, favicons, SVG, icons, images | `graphics-media` (batch 5) |
| Page copy, tone of voice, multilingual | `content-copy` (batch 6) |
| SEO, accessibility, performance, forms, GDPR, launch | `quality-launch` (batch 6) |

## Conventions

- Project state lives in `.site/` at the target project root, not in this repository.
- Generated files are never edited by hand; regenerate them from source.
- Scripts are dependency-free Node 18+ and safe to run directly.
