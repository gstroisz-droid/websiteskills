---
name: build-orchestrator
description: Entry point for building, rebuilding, redesigning or migrating any website, landing page, company site, shop or web app. Decides the delivery track (WordPress + Astra, or Cloudflare Workers), tracks project state, and routes each stage to the right domain skill. Start here before any other web skill — even when the user names a platform, a framework, or nothing at all.
---

# Build Orchestrator

General contractor for a website build. This skill does not write markup, design, or configure
anything. It decides what happens next and who does it.

Six domain skills sit below this one. Each domain holds several modules and loads only the one it
needs, so a project never carries the full catalogue in context.

## Routing

| The task is about | Use skill |
|---|---|
| Goals, audience, scope, sitemap, URLs, content types | `project-discovery` |
| Colors, type, spacing, layout, components, tokens, visual review | `design-system` |
| Astra, Elementor, Spectra, WP themes, CPT, WooCommerce, WP packaging | `wordpress-build` |
| Astro, static builds, Workers, D1/KV/R2, edge, headless | `cloudflare-build` |
| Logo, favicons, SVG, icons, illustrations, photos, image pipeline | `graphics-media` |
| Page copy, tone of voice, blog structure, multilingual content | `content-copy` |
| SEO, accessibility, Core Web Vitals, forms, GDPR, testing, launch | `quality-launch` |

Read one domain skill at a time. If a task genuinely spans two, read both — but never read all of
them "to see what's available". If nothing above fits, open `registry/catalog.json`, which lists
every module in the system with the skill that owns it.

Domain skills assume this one has already run and that `.site/` exists. If a user invokes a domain
skill directly on a fresh project, run discovery first.

## Project state

Everything decided lives in `.site/` at the target project root. This is shared memory between
domains — each reads it and writes back.

```
.site/
├── brief.md            project-discovery
├── ia.md
├── content-model.json
├── tokens.json         design-system — source of truth for all visuals
├── track.md            this skill
├── phase.md            current phase, one line, updated as work progresses
└── decisions.md        append-only: decision, date, why
```

Before starting anything, read `phase.md` and list `.site/`. A missing file means the phase that
produces it has not run. Resuming a project means continuing from the first gap, not restarting —
and saying out loud what you found, because the user may have changed direction since.

## Phases

| # | Phase | Domain | Output |
|---|-------|--------|--------|
| 0 | Discovery | `project-discovery` | `brief.md` |
| 1 | Structure | `project-discovery` | `ia.md`, `content-model.json` |
| 2 | Track decision | this skill | `track.md` |
| 3 | Art direction | `design-system` | direction notes |
| 4 | Tokens | `design-system` | `tokens.json` + platform outputs |
| 5 | Layout & components | `design-system` | layout specs |
| 6 | Copy | `content-copy` | page copy |
| 7 | Graphics | `graphics-media` | asset files |
| 8 | Build | `wordpress-build` or `cloudflare-build` | the site |
| 9 | Quality | `quality-launch` | fixes |
| 10 | Ship | `quality-launch` | package + docs |

Phases 3–7 overlap freely. Phases 0–2 and 8–10 are sequential. Update `phase.md` when moving
between them — it is what makes a resumed project cheap instead of confusing.

## Track decision (phase 2)

Write the answer and the reasoning to `.site/track.md`. Ask the user only if the brief does not
settle it.

**WordPress + Astra** when the client edits content themselves without a developer, the site needs
a shop, blog, bookings or memberships, hosting already exists, or handover is to someone
non-technical.

**Cloudflare Workers** when content changes rarely or a developer edits it, the site is marketing
or portfolio, speed is a selling point, hosting cost must be near zero, or it is an application
rather than a site.

**Both** when there is a marketing site plus a separate tool. Build both from one `tokens.json` so
they look like one product.

Close calls: WordPress for anything the client maintains, Workers for anything you maintain.

## Rules that hold across every project

**No markup before tokens.** A color, size, spacing value or radius that is not in `tokens.json`
either becomes a token or gets restated using an existing one. Hardcoded values are how a design
system quietly dies.

**No WordPress work on a live site.** Local environment or Playground first, always.

**Log irreversible decisions.** Append to `decisions.md`: what, when, why in one line.

**Stop for approval three times, and only three:** after the brief, after the art direction is
proposed, and before anything goes public. Asking at every step is as unhelpful as never asking.

**Done means runnable by someone else** — a tested import package for WordPress, a repo that
deploys with one command for Workers.

## Common shapes

**"Build me a site for my company"** — full sequence, 0 through 10.

**"Redesign this site"** — phase 0 uses the existing site as input, phase 1 becomes an audit plus a
redirect map, then normal from phase 3.

**"Move this WordPress site to Cloudflare"** — phases 0–1 are content extraction, skip 3–7 if the
design stays, then `cloudflare-build` with a redirect map. Preserving URLs matters more than
anything else here.

**"Make me a landing page"** — still run phase 0, timeboxed to a few questions, and collapse 3–5
into one pass. A landing page without discovery is a template with a logo on it.
