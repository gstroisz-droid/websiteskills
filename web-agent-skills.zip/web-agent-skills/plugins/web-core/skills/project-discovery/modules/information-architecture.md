
# Site Architecture & Information Architecture

Structure decided here becomes URLs, and URLs are the hardest thing to change later. Get this
wrong and you either live with it or spend the rebuild writing redirects.

Reads `.site/brief.md`. Produces `.site/ia.md` and `.site/content-model.json`.

## Sitemap

Derive pages from the goals in the brief, not from a generic template. A site does not need an
"About" page because sites have About pages — it needs one if trust is a barrier to the goal.

Keep the primary navigation to five to seven items. More than that and users stop reading it; the
overflow belongs in the footer or inside section pages.

Depth matters more than breadth: three clicks from home to anything is a reasonable ceiling for a
small site. If something needs four, question whether the middle level is a real page or just a
menu pretending to be one.

For each page record: purpose, primary action, who it is for, and what content it needs. A page
with no primary action is either a leaf of a content section or it should not exist.

## URL structure

Decide these before the first page is built:

- Lowercase, hyphen-separated, no dates in article URLs unless the content is genuinely
  time-bound — dates make evergreen articles look stale
- Directory structure that mirrors the navigation, so a URL is readable without the page
- Singular vs plural for archives, chosen once and applied everywhere (`/services/` and
  `/services/consulting/`)
- Trailing slash convention, chosen once — mixing them creates duplicate content
- For multilingual sites, decide the pattern now (`/no/`, `/en/`, or subdomains) even if only one
  language launches, because retrofitting a language prefix rewrites every URL

## Templates

List the page templates the site needs, not the pages. Ten service pages are one template. This
list drives the build: each template is a thing someone has to design and build, each page is
content poured into one.

Typical set: home, section landing, content page, article, article archive, contact, plus
product/product archive for a shop and a legal page template. Anything beyond that needs
justification.

## Content model

Write `.site/content-model.json`. This translates directly into WordPress custom post types and
fields, or into Astro content collections — same structure, two backends.

```json
{
  "types": [
    {
      "name": "service",
      "label": "Services",
      "archive": "/services/",
      "fields": [
        { "name": "title", "type": "text", "required": true },
        { "name": "summary", "type": "text", "max": 160 },
        { "name": "body", "type": "richtext" },
        { "name": "price_from", "type": "number", "required": false },
        { "name": "featured_image", "type": "image" }
      ],
      "taxonomies": ["service_category"]
    }
  ],
  "taxonomies": [
    { "name": "service_category", "label": "Service categories", "hierarchical": true }
  ]
}
```

Rules that save pain later: every field a client will edit needs a label they understand; anything
repeated across pages is a field, not copy-pasted text; anything with its own URL is a content
type, not a field on another type.

Resist modelling everything. Three well-chosen types beat nine that the client never fills in.

## Navigation

Specify separately: primary nav, footer nav, mobile behaviour, and any utility nav (language,
account, search). Label menu items with the words users would use, not internal terminology — a
client's "Solutions" is often the visitor's "What you do".

Note which items are links and which are dropdowns. Dropdowns on touch devices need a deliberate
decision: does the parent link go somewhere, or only open the submenu?

## Redirect map (rebuilds only)

When replacing an existing site, crawl or list the current URLs and map each one to its new
location. Every old URL either maps to a new page or is deliberately retired with a 410. Losing
this step loses the site's search rankings, and it is the single most common regret after a
relaunch.

Record it as a two-column table in `ia.md`, ready for `wp-package-deploy` or
`cloudflare-workers-deploy` to implement.

## Output

`.site/ia.md` contains: the sitemap as an indented list, the URL conventions, the template list,
the navigation spec, and the redirect map if applicable. Show it to the user before design starts
— structural changes are cheap now and expensive after phase 5.
