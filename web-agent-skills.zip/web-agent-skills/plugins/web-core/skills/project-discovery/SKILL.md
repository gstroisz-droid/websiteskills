---
name: project-discovery
description: Establishes what a website project actually is before anything is designed or built — goals, audience, scope, content sources, sitemap, navigation, URL structure, page templates and content model. Use when starting a new site, when a request lacks stated goals or audience, and for any question about site structure, menus, page hierarchy, URL naming, custom post types or redirect maps. Not for visual design or implementation.
---

# Project Discovery

Two modules. Read the one the task needs; read both when starting a project from scratch.

| Task | Read |
|------|------|
| Goals, audience, scope, budget, content sources, constraints, success criteria | `modules/brief.md` |
| Sitemap, navigation, URLs, page templates, content types, redirect map | `modules/information-architecture.md` |

Order matters: the brief feeds the architecture. Doing architecture first produces a structure
that serves no stated goal.

## Shared rules

**Ask in rounds of three, not one at a time.** Batch related questions. An interrogation makes
people give shorter answers, which is the opposite of what discovery needs.

**Infer before asking.** If a domain or company name was given, look at it. Asking what a company
does when its URL is on screen wastes the user's time and signals inattention.

**Two rounds, then assume.** Anything still unknown becomes a flagged assumption in the brief and
the project moves on. Assumptions get validated at the art direction gate, not before. A brief with
visible assumptions beats a stalled project.

**Push once on vague answers.** "Modern" and "professional" carry no information. Ask for two or
three sites they respond to and what specifically about each. If they can name none, art direction
is yours to lead and should be presented as options.

**Write to `.site/`.** `brief.md`, `ia.md`, `content-model.json`. Later phases read these files
rather than the conversation, so anything not written down is lost.

## Output gate

The brief is one of the three approval gates in `build-orchestrator`. Show it, ask for
corrections, and do not treat silence as approval. Structural changes cost nothing now and a
rebuild later.
