---
name: design-system
description: Defines and maintains a project's visual language — colors, typefaces, type scale, spacing, radii, shadows, layout composition and components — as tokens that compile to WordPress theme.json, an Elementor kit, CSS custom properties and Tailwind. Use before writing any markup or CSS, for any question about a site's look, palette, fonts, spacing or layout, and whenever one brand must ship on two platforms.
---

# Design System

Every visual decision on the project lives here, expressed once and compiled to whichever platform
the build uses. Downstream skills generate their styling from these outputs rather than typing
values by hand.

## Modules

| Task | Read |
|------|------|
| Defining, editing or compiling design tokens; wiring them into WordPress or a static build | `modules/tokens.md` |

Batch 2 adds: `art-direction`, `typography`, `color`, `layout`, `components`, `motion`,
`design-review`. Until then, apply the rules below directly and record every decision in
`tokens.json` so nothing is lost when those modules arrive.

## Rules that survive every module

**Tokens first, markup second.** A value that is not in `tokens.json` either becomes a token or
gets restated with an existing one. A one-off hex in a component is the first crack in the system.

**Semantic names, never literal ones.** `brand`, `ink`, `surface`, `line` — not `blue-500`. A
literal name becomes a lie the first time the brand shifts, and it says nothing about where the
color belongs.

**Contrast is checked when the token is defined**, not at review. Body text needs 4.5:1 against its
surface, large text 3:1. Fixing this after fifty components use the palette means touching fifty
components.

**Keep the palette under about ten entries.** Every extra color is a decision someone has to make
on every component, forever.

**Fluid sizing above 1rem, fixed below.** Fluid micro-spacing produces sub-pixel jitter for no
visible benefit.

**Design for the editor too.** On WordPress, styles that exist only on the front end mean the
client sees something different while editing, and they will "fix" it.

## What generic looks like

The default output of any generative system converges on the same page: centered hero with a
gradient, three equal feature cards, uniform border radius everywhere, a sans-serif that ships with
the framework, and generous symmetrical whitespace. It is competent and forgettable.

Escaping it is not decoration added at the end — it comes from committing early to a few specific
choices and applying them consistently: one distinctive typeface doing real work, a palette that is
not blue-on-white, an asymmetry that repeats, a spacing rhythm with actual contrast between tight
and loose. Two or three strong commitments beat twenty small flourishes.

If a layout could belong to any company in any industry, it is not finished.
