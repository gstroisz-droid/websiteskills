# Platform mapping

Where each generated file goes, and what a token is called once it gets there.

## Naming translation

| tokens.json | CSS | theme.json | Elementor | Tailwind |
|---|---|---|---|---|
| `color.brand` | `--color-brand` | `var(--wp--preset--color--brand)` | Global Color "Primary" | `text-brand`, `bg-brand` |
| `font.heading` | `--font-heading` | `var(--wp--preset--font-family--heading)` | Global Font "Primary" | `font-heading` |
| `size.step-2` | `--size-step-2` | `var(--wp--preset--font-size--step-2)` | manual per widget | `text-step-2` |
| `space.l` | `--space-l` | `var(--wp--preset--spacing--60)` | Gap / padding value | `p-l`, `gap-l` |

WordPress generates its `--wp--preset--*` variables from `theme.json` automatically. Elementor
does not expose spacing or type scale as globals — only colors and typography — so sizes are
applied per widget from the values in `tokens.css`, which the child theme also enqueues.

## WordPress child theme

```
astra-child/
├── style.css
├── functions.php
├── theme.json              ← merge generated theme.json here
└── assets/
    ├── css/tokens.css      ← copy generated tokens.css here
    └── fonts/              ← self-hosted woff2
```

In `functions.php`, enqueue `tokens.css` before the child stylesheet so component CSS can use the
variables. Enqueue it on the front end and in the block editor (`enqueue_block_editor_assets`) so
the editor preview matches the front end — skipping the editor side is why so many WordPress sites
look different in the admin than in reality.

Merging `theme.json`: if the child theme already has one, combine the `settings` objects rather
than replacing the file. Astra's own values are the fallback; anything the child defines wins.

`defaultPalette: false` in the generated file removes WordPress's built-in colors from the picker.
Keep it that way — leaving them in means a client eventually picks one and breaks the system.

## Elementor kit

1. Elementor → Tools → Import/Export Kit → Export, choosing Site Settings only
2. Unzip; find `site-settings.json`
3. Merge the `settings` object from `elementor-kit.json` into it, replacing `system_colors` and
   `system_typography` wholesale
4. Re-zip and import back

The `_id` values for system colors and typography are fixed strings (`primary`, `secondary`,
`text`, `accent`). Elementor's UI references them by id, so they must not be renamed — only their
titles and values change. Extra colors go in `custom_colors`, where the `_id` is an arbitrary short
string that only needs to be unique.

After import, spot-check one page: if globals applied correctly, changing a Global Color in the UI
should visibly move every element bound to it.

## Astro / static

```
src/styles/
├── tokens.css       ← generated, do not edit
├── reset.css
└── global.css       ← uses var(--…) only
```

Import order in the layout: `tokens.css`, `reset.css`, `global.css`, then component styles. If
Tailwind is in use:

```js
import tokens from "./build/tokens/tokens.tailwind.js";
export default { theme: { extend: tokens } };
```

The Tailwind values resolve to the same custom properties rather than to literal values, so
utilities and hand-written CSS stay in sync and a token change needs no rebuild of the config.

## Verifying both platforms match

Build one identical test section — heading, paragraph, button, card — on each platform and compare
screenshots at 375px and 1440px. Differences almost always come from one of three places: fonts
loading from different sources, the WordPress side missing the editor stylesheet, or a component
that hardcoded a value instead of using a token.
