#!/usr/bin/env node
/**
 * build-tokens.mjs — compile one tokens.json into every platform format.
 *
 *   node build-tokens.mjs .site/tokens.json --out build/tokens
 *
 * Emits:
 *   tokens.css          CSS custom properties (Astro / any static build)
 *   theme.json          WordPress theme.json fragment (settings only)
 *   elementor-kit.json  Elementor Site Settings fragment (merge into an exported kit)
 *   tokens.tailwind.js  Tailwind theme extension
 *   fonts.md            font loading instructions for both platforms
 *
 * No dependencies. Node 18+.
 */

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";

/* ---------- args ---------- */

const args = process.argv.slice(2);
const src = args.find((a) => !a.startsWith("--"));
const outIdx = args.indexOf("--out");
const outDir = outIdx > -1 ? args[outIdx + 1] : "build/tokens";

if (!src) {
  console.error("usage: node build-tokens.mjs <tokens.json> [--out <dir>]");
  process.exit(1);
}

const T = JSON.parse(readFileSync(resolve(src), "utf8"));
mkdirSync(resolve(outDir), { recursive: true });

const meta = T.meta ?? {};
const vpMin = meta.viewportMin ?? 320;
const vpMax = meta.viewportMax ?? 1440;
const root = meta.rootFontSize ?? 16;

/* ---------- helpers ---------- */

const toRem = (v) =>
  typeof v === "number" ? v / root : parseFloat(String(v).replace(/rem|px/, ""));

const isPx = (v) => typeof v === "string" && v.endsWith("px");

/** Fluid value between two sizes across the viewport range, as a clamp(). */
function clamp(min, max) {
  const minRem = isPx(min) ? toRem(min) : toRem(min);
  const maxRem = isPx(max) ? toRem(max) : toRem(max);
  if (Math.abs(minRem - maxRem) < 0.001) return `${minRem}rem`;
  const slope = ((maxRem - minRem) * root * 100) / (vpMax - vpMin);
  const intercept = minRem - (slope / 100) * (vpMin / root);
  return `clamp(${round(minRem)}rem, ${round(intercept)}rem + ${round(slope)}vw, ${round(maxRem)}rem)`;
}

const round = (n) => Math.round(n * 1000) / 1000;

/** A size entry is either a plain value or {min, max} for a fluid one. */
function sizeValue(v) {
  if (v && typeof v === "object" && "min" in v) return clamp(v.min, v.max);
  return String(v);
}

const titleCase = (s) =>
  s.replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

/* ---------- 1. CSS custom properties ---------- */

const cssLines = [];
cssLines.push(`/* generated from ${src} — do not edit by hand */`);
cssLines.push(":root {");

for (const [k, v] of Object.entries(T.color ?? {}))
  cssLines.push(`  --color-${k}: ${v};`);

for (const [k, v] of Object.entries(T.font ?? {}))
  cssLines.push(`  --font-${k}: ${v.stack ?? v.family};`);

for (const [k, v] of Object.entries(T.size ?? {}))
  cssLines.push(`  --size-${k}: ${sizeValue(v)};`);

for (const [k, v] of Object.entries(T.space ?? {}))
  cssLines.push(`  --space-${k}: ${sizeValue(v)};`);

for (const [k, v] of Object.entries(T.radius ?? {}))
  cssLines.push(`  --radius-${k}: ${v};`);

for (const [k, v] of Object.entries(T.shadow ?? {}))
  cssLines.push(`  --shadow-${k}: ${v};`);

for (const [k, v] of Object.entries(T.container ?? {}))
  cssLines.push(`  --container-${k}: ${v};`);

cssLines.push("}");
writeFileSync(resolve(outDir, "tokens.css"), cssLines.join("\n") + "\n");

/* ---------- 2. WordPress theme.json ---------- */

const themeJson = {
  $schema: "https://schemas.wp.org/trunk/theme.json",
  version: 3,
  settings: {
    appearanceTools: true,
    useRootPaddingAwareAlignments: true,
    color: {
      defaultPalette: false,
      defaultGradients: false,
      palette: Object.entries(T.color ?? {}).map(([slug, color]) => ({
        slug,
        name: titleCase(slug),
        color,
      })),
    },
    typography: {
      fluid: true,
      defaultFontSizes: false,
      fontFamilies: Object.entries(T.font ?? {}).map(([slug, f]) => ({
        slug,
        name: titleCase(slug),
        fontFamily: f.stack ?? f.family,
      })),
      fontSizes: Object.entries(T.size ?? {}).map(([slug, v]) => {
        const entry = { slug, name: titleCase(slug), size: sizeValue(v) };
        if (v && typeof v === "object" && "min" in v) {
          entry.fluid = { min: String(v.min), max: String(v.max) };
          entry.size = String(v.max);
        }
        return entry;
      }),
    },
    spacing: {
      defaultSpacingSizes: false,
      spacingSizes: Object.entries(T.space ?? {}).map(([slug, v], i) => ({
        slug: String((i + 1) * 10),
        name: titleCase(slug),
        size: sizeValue(v),
      })),
    },
    layout: {
      contentSize: T.container?.content ?? "48rem",
      wideSize: T.container?.max ?? "72rem",
    },
  },
};
writeFileSync(
  resolve(outDir, "theme.json"),
  JSON.stringify(themeJson, null, 2) + "\n",
);

/* ---------- 3. Elementor kit fragment ---------- */

const ELEMENTOR_SLOTS = ["primary", "secondary", "text", "accent"];
const colorEntries = Object.entries(T.color ?? {});

const systemColors = ELEMENTOR_SLOTS.map((slot, i) => {
  const [name, color] = colorEntries[i] ?? [slot, "#000000"];
  return { _id: slot, title: titleCase(name), color };
});

const customColors = colorEntries.slice(ELEMENTOR_SLOTS.length).map(([name, color]) => ({
  _id: name.replace(/[^a-z0-9]/gi, "").slice(0, 7) || "custom",
  title: titleCase(name),
  color,
}));

const fontEntries = Object.entries(T.font ?? {});
const systemTypography = ["primary", "secondary", "text", "accent"].map((slot, i) => {
  const [name, f] = fontEntries[Math.min(i, Math.max(fontEntries.length - 1, 0))] ?? [
    slot,
    { family: "Arial" },
  ];
  return {
    _id: slot,
    title: titleCase(name),
    typography_typography: "custom",
    typography_font_family: f.family,
    typography_font_weight: String(f.weights?.[i === 0 ? f.weights.length - 1 : 0] ?? 400),
  };
});

const kit = {
  _comment:
    "Fragment. Merge into the site-settings of a kit exported from Elementor — do not import standalone.",
  settings: {
    system_colors: systemColors,
    custom_colors: customColors,
    system_typography: systemTypography,
    container_width: {
      unit: "px",
      size: Math.round(toRem(T.container?.max ?? "72rem") * root),
    },
    space_between_widgets: {
      unit: "px",
      size: Math.round(toRem(T.space?.m ?? "1.5rem") * root),
    },
  },
};
writeFileSync(
  resolve(outDir, "elementor-kit.json"),
  JSON.stringify(kit, null, 2) + "\n",
);

/* ---------- 4. Tailwind theme extension ---------- */

const tw = {
  colors: Object.fromEntries(
    Object.keys(T.color ?? {}).map((k) => [k, `var(--color-${k})`]),
  ),
  fontFamily: Object.fromEntries(
    Object.keys(T.font ?? {}).map((k) => [k, `var(--font-${k})`]),
  ),
  fontSize: Object.fromEntries(
    Object.keys(T.size ?? {}).map((k) => [k, `var(--size-${k})`]),
  ),
  spacing: Object.fromEntries(
    Object.keys(T.space ?? {}).map((k) => [k, `var(--space-${k})`]),
  ),
  borderRadius: Object.fromEntries(
    Object.keys(T.radius ?? {}).map((k) => [k, `var(--radius-${k})`]),
  ),
  boxShadow: Object.fromEntries(
    Object.keys(T.shadow ?? {}).map((k) => [k, `var(--shadow-${k})`]),
  ),
};
writeFileSync(
  resolve(outDir, "tokens.tailwind.js"),
  `// generated from ${src} — do not edit by hand\nexport default ${JSON.stringify(tw, null, 2)};\n`,
);

/* ---------- 5. Font loading notes ---------- */

const fontNotes = ["# Font loading", ""];
for (const [slug, f] of Object.entries(T.font ?? {})) {
  fontNotes.push(`## ${titleCase(slug)} — ${f.family}`);
  fontNotes.push(`Weights: ${(f.weights ?? [400]).join(", ")} · Source: ${f.source ?? "local"}`);
  fontNotes.push("");
  fontNotes.push(
    "- Self-host the woff2 files. Third-party font CDNs cost a connection on first paint and complicate consent.",
  );
  fontNotes.push("- WordPress: register the family in the child theme so it appears in Elementor and the block editor.");
  fontNotes.push("- Static build: `@font-face` with `font-display: swap` plus a `<link rel=preload>` for the weight used above the fold.");
  fontNotes.push("");
}
writeFileSync(resolve(outDir, "fonts.md"), fontNotes.join("\n"));

/* ---------- done ---------- */

console.log(`tokens → ${outDir}`);
console.log("  tokens.css, theme.json, elementor-kit.json, tokens.tailwind.js, fonts.md");
console.log(
  `  ${Object.keys(T.color ?? {}).length} colors · ${Object.keys(T.font ?? {}).length} families · ${Object.keys(T.size ?? {}).length} sizes · ${Object.keys(T.space ?? {}).length} spacing steps`,
);
