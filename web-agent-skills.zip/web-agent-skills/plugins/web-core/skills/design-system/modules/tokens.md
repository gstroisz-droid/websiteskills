
# Design tokens

One source of truth for every visual decision. Everything downstream — the Astra child theme, the
Elementor kit, the Astro build — is generated from it rather than hand-typed.

This matters most when a project ships on both platforms. Hand-maintaining a palette in the
Elementor UI and again in a stylesheet guarantees they drift within a week.

## Workflow

1. Read the art direction output (the art-direction, typography and color modules).
   If none exists, those skills run first — this skill records decisions, it does not make them.
2. Write `.site/tokens.json` using the schema in `../assets/tokens.example.json`.
3. Compile: `node ../scripts/build-tokens.mjs .site/tokens.json --out build/tokens`
4. Wire the outputs into whichever platform the project uses (below).
5. Re-run the script after any token change. Never edit the generated files.

## The token file

Copy `../assets/tokens.example.json` and replace the values. Structure is fixed; the number of
entries is not.

**Colors** are semantic, not literal: `brand`, `ink`, `surface`, `accent`, `line`. Never `blue-500`
— a literal name becomes a lie the first time the brand shifts, and it tells you nothing about
where the color belongs. Keep the palette under about ten entries; every extra color is a decision
someone has to make on every component.

**Type sizes** use a modular scale with fluid `{min, max}` pairs, which the script turns into
`clamp()`. Name them by position (`step-0` is body text, negative steps are smaller) rather than by
use, so one size can serve several roles without a misleading name.

**Spacing** follows the same pattern. Large steps should be fluid; small ones (below about 1rem)
should not — fluid micro-spacing produces sub-pixel jitter for no visible benefit.

**Containers** define `content` (reading width, roughly 44rem for comfortable line length), `max`
(wide sections), and `gutter`.

## Generated outputs

| File | Goes where |
|------|-----------|
| `tokens.css` | Static builds — import once in the global stylesheet |
| `theme.json` | Merge into the Astra child theme's `theme.json` |
| `elementor-kit.json` | Merge into an exported Elementor kit's site settings |
| `tokens.tailwind.js` | Import into `tailwind.config` under `theme.extend` |
| `fonts.md` | Font loading instructions for both platforms |

## Wiring into WordPress

Merge the generated `theme.json` into the child theme's own `theme.json`. Astra ships a basic one,
and the child theme's file wins — this is how the palette reaches the block editor without any
plugin.

For Elementor, the kit fragment is not importable on its own. Export a kit from the site first,
merge the `settings` object into its site settings, then re-import. `elementor-build` covers the
mechanics. The reason this matters: Elementor's Global Colors and Global Fonts are what page-level
controls reference, so getting tokens in there means a later palette change updates every page at
once instead of requiring a page-by-page edit.

Register the font families in the child theme so Elementor and the block editor both offer them.
Self-hosted woff2, not a font CDN — see `fonts.md`.

Read `../references/platform-mapping.md` for the exact merge points and the naming translation
between the four output formats.

## Wiring into a static build

Import `tokens.css` before any component styles. Reference tokens as `var(--color-brand)`,
`var(--size-step-2)`, never as literal values. If Tailwind is in use, load
`tokens.tailwind.js` into `theme.extend` — the utilities then resolve to the same custom
properties, so both authoring styles hit one source.

## Rules

Nothing visual gets hardcoded. If a value is needed that no token provides, the decision is whether
it belongs in the system: add it as a token, or restate the design using an existing one. A
one-off hex in a component is the first crack.

Contrast is checked at token definition time, not at review. Every text-on-surface pair needs 4.5:1
for body text and 3:1 for large text. Fixing this after fifty components use the palette means
touching all fifty. quality-launch verifies it later, but catching it here is nearly free.

Token changes are not visual tweaks — they cascade to every page on both platforms. Re-run the
build, then re-check the pages that use the changed token most heavily.

## Adding a second platform later

Nothing changes: the token file is already the source. Run the script, wire the relevant output,
and the second platform matches. This is why the file exists even on single-platform projects.
